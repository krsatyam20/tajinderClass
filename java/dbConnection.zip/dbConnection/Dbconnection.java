package dbConnection;
import java.sql.*;
import java.sql.DriverManager;
import java.util.Scanner;

public class Dbconnection {

	public static void main(String[] args) {
		
		Scanner sc= new Scanner(System.in);	
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/manager","root","");
			
		Statement stm=con.createStatement();
		
		String name;	
		int roll;
		System.out.println("please enter the rollno.");
		roll=sc.nextInt();
		System.out.println("please enter the Name");
		name=sc.next();
		
		int rs=stm.executeUpdate("insert into customers(cid,cname)  values('"+roll+"','"+name +"')");
		
		con.close();
		}
		catch(Exception e)
		{
			System.out.println("not Connected");
		}
		
			
}
}
