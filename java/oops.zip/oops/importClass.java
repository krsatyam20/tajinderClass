package oops;

public class importClass {

	public static void show() {
		System.out.println("Hello Import class");
	}
	
}
