package javaProject;

public class Swapnumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      int x,y,z;
      x=10;
      y=30;
      
      z=x;
      x=y;
      y=z;
      System.out.println("Swap the value of x and y"+x +y);
      
      int k,l;
      
      k=20;
      l=40;
      
      k= k+l;
      
      l=k-l;
      k=k-l;
      System.out.println(k +"=====" + l);
	}

}
