package javaProject;

import javaProjectPakage.ClassWithPakage;

class Addition{
	public void hello() {
	System.out.println("hello Tajinder using class");
	}
	
}

public class ClassStudy {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Addition obj= new Addition();
		
		obj.hello();
		
		SecondClassStudy obj2 = new SecondClassStudy();
		obj2.add(10, 20);
		
		ClassWithPakage obj3= new ClassWithPakage();
		
		obj3.show();
	}

}
