package javaProject;

public class MyFirstJavaProgram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("hello Tajinder");
		System.out.println();
		System.out.print("================ ");
		
	}

}
