package javaProjectPakage;

public class ClassWithPakage {

	public void show() {
		System.out.println("ClassWithPakage");
	}
}
