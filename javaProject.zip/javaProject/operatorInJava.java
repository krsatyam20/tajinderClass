package javaProject;

public class operatorInJava {

	public static void main(String[] args) {
		
//Airthmetic Operator
		// + - * / = %
		int a,b,c;
		
		a= 10;
		b=20;
		System.out.println("value of a =" + a);
		
		c= a+b;
		
		System.out.println(c);
		
	//WAP to find out the square of a given number.
		
	int x= 2;
	
	int y = x*x;
	
	System.out.println("Square of x is= " + y);
		
		
	}

}
